import 'dart:convert';
import 'package:flutter/material.dart';
import '../base_message_ui.dart';

class InteractiveMessageUi extends StatelessWidget {
  final String messageText;
  final bool isSentByMe;
  final DateTime createdAt;
  final Size mediaQuery;
  final String deliveryStatus;

  const InteractiveMessageUi({
    super.key,
    required this.messageText,
    required this.isSentByMe,
    required this.createdAt,
    required this.mediaQuery,
    required this.deliveryStatus,
  });

  @override
  Widget build(BuildContext context) {
    String displayText = 'Unsupported message format';
    Map<String, dynamic>? interactiveContent;

    try {
      // Parse the main message_text
      final messageJson = jsonDecode(messageText);

      if (messageJson['interactive'] != null &&
          messageJson['interactive']['nfm_reply'] != null) {
        final nfmReply = messageJson['interactive']['nfm_reply'];

        // Decode response_json if present
        if (nfmReply['response_json'] != null) {
          final responseJson =
              jsonDecode(nfmReply['response_json']); // Decode nested JSON

          // Format the response data into displayable text
          displayText = _formatInteractiveResponse(responseJson);
        }
      }
    } catch (e) {
      displayText = 'Error parsing message';
      print('Error parsing interactive message: $e');
    }

    return BaseMessageUi(
      isSentByMe: isSentByMe,
      createdAt: createdAt,
      mediaQuery: mediaQuery,
      deliveryStatus: deliveryStatus,
      child: Text(
        displayText,
        softWrap: true,
        overflow: TextOverflow.visible,
        style: const TextStyle(fontSize: 14),
      ),
    );
  }

  String _formatInteractiveResponse(Map<String, dynamic> responseJson) {
    final buffer = StringBuffer();

    responseJson.forEach((key, value) {
      if (value is List) {
        buffer.writeln('$key: ${value.join(", ")}');
      } else {
        buffer.writeln('$key: $value');
      }
    });

    return buffer.toString().trim();
  }
}
