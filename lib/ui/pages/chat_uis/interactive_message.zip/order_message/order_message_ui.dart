import 'dart:convert';
import 'package:flutter/material.dart';

import '../base_message_ui.dart';

class OrderMessageUi extends StatelessWidget {
  final String text;
  final bool isSentByMe;
  final DateTime createdAt;
  final Size mediaQuery;
  final String deliveryStatus;

  const OrderMessageUi({
    super.key,
    required this.text,
    required this.isSentByMe,
    required this.createdAt,
    required this.mediaQuery,
    required this.deliveryStatus,
  });

  @override
  Widget build(BuildContext context) {
    Widget content;

    try {
  if (text.isNotEmpty) {
        // Parse JSON and display order details
        final Map<String, dynamic> messageData = jsonDecode(text);
        final List<dynamic>? productItems = messageData['order']?['product_items'];

        if (productItems != null) {
          content = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: productItems.map((item) {
              final retailerId = item['product_retailer_id'] ?? 'Unknown';
              final quantity = item['quantity'] ?? 0;
              final price = item['item_price'] ?? 0;
              final currency = item['currency'] ?? 'N/A';
              return Container(
                color: const Color.fromARGB(255, 170, 190, 170),
                margin: EdgeInsets.all(2),
                child: SelectableText(
                  'Product ID: $retailerId\nQuantity: $quantity\nPrice: $price $currency',
                  style: const TextStyle(fontSize: 14),
                ),
              );
            }).toList(),
          );
        } else {
          content = const Text('No order details available.');
        }
      } else {
        content = const Text('');
      }
    } catch (e) {
      content = const Text('');
    }

    return BaseMessageUi(
      isSentByMe: isSentByMe,
      createdAt: createdAt,
      mediaQuery: mediaQuery,
      deliveryStatus: deliveryStatus,
      child: content,
    );
  }
}
